import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:getflutter/components/carousel/gf_carousel.dart';
import 'package:getflutter/components/image/gf_image_overlay.dart';
import 'package:multilocationGroceryApp/screens/categories/allcategories.dart';
import 'package:multilocationGroceryApp/screens/categories/subcategories.dart';
import 'package:multilocationGroceryApp/screens/product/all_deals.dart';
import 'package:multilocationGroceryApp/screens/product/all_products.dart';
import 'package:multilocationGroceryApp/screens/product/product-details.dart';
import 'package:multilocationGroceryApp/service/auth-service.dart';
import 'package:multilocationGroceryApp/service/cart-service.dart';
import 'package:multilocationGroceryApp/service/common.dart';
import 'package:multilocationGroceryApp/service/constants.dart';
import 'package:multilocationGroceryApp/service/localizations.dart';
import 'package:multilocationGroceryApp/service/product-service.dart';
import 'package:multilocationGroceryApp/service/sentry-service.dart';
import 'package:multilocationGroceryApp/style/style.dart';
import 'package:multilocationGroceryApp/widgets/loader.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:multilocationGroceryApp/widgets/categoryBlock.dart';
import 'package:multilocationGroceryApp/widgets/productCard.dart';
import 'package:multilocationGroceryApp/widgets/cardOverlay.dart';

SentryError sentryError = new SentryError();

class Store extends StatefulWidget {
  final Map localizedValues;
  final String locale, currentLocation;
  Store({Key key, this.currentLocation, this.locale, this.localizedValues})
      : super(key: key);
  @override
  _StoreState createState() => _StoreState();
}

class _StoreState extends State<Store> with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKeydrawer =
      new GlobalKey<ScaffoldState>();

  RefreshController _refreshController =
      RefreshController(initialRefresh: false);
  bool getTokenValue = true,
      isLocationLoading = false,
      isBannerLoading = false,
      isLoadingAllData = false;
  List categoryList,
      productsList,
      searchProductList,
      dealList,
      topDealList,
      bannerList;
  String currency;
  final List<String> assetImg = [
    'lib/assets/images/product.png',
  ];

  TabController tabController;

  var addressData;
  String locale;
  @override
  void initState() {
    getToken();
    getBanner();
    getAllData();

    super.initState();
    tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  getToken() async {
    await Common.getCurrency().then((value) {
      currency = value;
    });
    await Common.getSelectedLanguage().then((value) async {
      locale = value;
      await Common.getToken().then((onValue) {
        if (onValue != null) {
          if (mounted) {
            setState(() {
              getTokenValue = true;
              getCartData();
            });
          }
        } else {
          if (mounted) {
            setState(() {
              getTokenValue = false;
            });
          }
        }
      }).catchError((error) {
        sentryError.reportError(error, null);
      });
    });
  }

  getCartData() {
    CartService.getProductToCart().then((value) {
      if (value['response_code'] == 200 && value['response_data'] is Map) {
        Common.setCartData(value['response_data']);
      } else if (value['response_code'] == 403) {
        Common.setCartData(null);
      } else {
        Common.setCartData(null);
      }
    });
  }

  getBanner() async {
    if (mounted) {
      setState(() {
        isBannerLoading = true;
      });
    }
    await Common.getBanner().then((value) {
      if (value == null || value['response_data'] == null) {
        if (mounted) {
          setState(() {
            getBannerData();
          });
        }
      } else {
        if (mounted) {
          setState(() {
            getBannerData();
            bannerList = value['response_data']['banners'];
            isBannerLoading = false;
          });
        }
      }
    });
  }

  getBannerData() async {
    await LoginService.getBanner().then((onValue) {
      try {
        _refreshController.refreshCompleted();
        if (mounted) {
          setState(() {
            bannerList = onValue['response_data']['banners'];
            isBannerLoading = false;
          });
        }
      } catch (error, stackTrace) {
        sentryError.reportError(error, stackTrace);
      }
    }).catchError((error) {
      sentryError.reportError(error, null);
    });
  }

  getAllData() async {
    if (mounted) {
      setState(() {
        isLoadingAllData = true;
      });
    }
    await Common.getAllData().then((value) {
      if (value == null || value['response_data'] == null) {
        if (mounted) {
          setState(() {
            getAllDataMethod();
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isLoadingAllData = false;
            categoryList = value['response_data']['categories'];
            productsList = value['response_data']['products'];
            topDealList = value['response_data']['topDeals'];
            dealList = value['response_data']['dealsOfDay'];

            getAllDataMethod();
          });
        }
      }
    });
  }

  getAllDataMethod() async {
    await ProductService.getProdCatDealTopDeal().then((onValue) {
      try {
        _refreshController.refreshCompleted();
        if (onValue['response_code'] == 200) {
          if (mounted) {
            setState(() {
              categoryList = onValue['response_data']['categories'];
              productsList = onValue['response_data']['products'];
              topDealList = onValue['response_data']['topDeals'];
              dealList = onValue['response_data']['dealsOfDay'];
              isLoadingAllData = false;
            });
          }
        } else {
          if (mounted) {
            setState(() {
              categoryList = [];
              productsList = [];
              dealList = [];
              topDealList = [];
              isLoadingAllData = false;
            });
          }
        }
      } catch (error, stackTrace) {
        sentryError.reportError(error, stackTrace);
      }
    }).catchError((error) {
      sentryError.reportError(error, null);
    });
  }

  categoryRow() {
    return Column(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Expanded(
              child: Text(
                MyLocalizations.of(context).explorebyCategories,
                style: textBarlowMediumBlack(),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AllCategories(
                      locale: widget.locale,
                      localizedValues: widget.localizedValues,
                      getTokenValue: getTokenValue,
                    ),
                  ),
                );
              },
              child: Text(
                MyLocalizations.of(context).viewAll,
                style: textBarlowMediumPrimary(),
              ),
            )
          ],
        ),
        SizedBox(height: 20),
        SizedBox(
          height: 100,
          child: ListView.builder(
            physics: ScrollPhysics(),
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemCount: categoryList.length != null ? categoryList.length : 0,
            itemBuilder: (BuildContext context, int index) {
              return InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SubCategories(
                          locale: widget.locale,
                          localizedValues: widget.localizedValues,
                          catId: categoryList[index]['_id'],
                          isSubCategoryAvailable: categoryList[index]
                                  ['isSubCategoryAvailable'] ??
                              false,
                          catTitle:
                              '${categoryList[index]['title'][0].toUpperCase()}${categoryList[index]['title'].substring(1)}',
                          token: getTokenValue),
                    ),
                  );
                },
                child: CategoryBlock(
                  image: categoryList[index]['filePath'] == null
                      ? categoryList[index]['imageUrl']
                      : categoryList[index]['filePath'],
                  title: categoryList[index]['title'],
                  isPath:
                      categoryList[index]['filePath'] == null ? false : true,
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  banner() {
    return GFCarousel(
      autoPlay: true,
      pagination: true,
      pagerSize: 10,
      viewportFraction: 1.0,
      activeIndicator: primary,
      passiveIndicator: darkGrey.withOpacity(0.6),
      height: 150,
      aspectRatio: 2,
      onPageChanged: (_) {
        setState(() {
          //do not remove this setstate
        });
      },
      items: bannerList.map((url) {
        return InkWell(
          onTap: () {
            if (url['bannerType'] == "Product") {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProductDetails(
                    locale: widget.locale,
                    localizedValues: widget.localizedValues,
                    productID: url['product'],
                  ),
                ),
              );
            } else {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SubCategories(
                      locale: widget.locale,
                      localizedValues: widget.localizedValues,
                      catId: url['category'],
                      catTitle:
                          '${url['title'][0].toUpperCase()}${url['title'].substring(1)}',
                      token: getTokenValue),
                ),
              );
            }
          },
          child: Stack(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: Container(
                  height: 103,
                  padding: EdgeInsets.only(left: 20, right: 20),
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      color: primary,
                      borderRadius: BorderRadius.all(Radius.circular(5))),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.only(
                          right: locale == 'ar' ? 0 : 100,
                          left: locale == 'ar' ? 100 : 0,
                        ),
                        child: Text(
                          url['title'],
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                          style: textbarlowBoldwhite(),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          if (url['bannerType'] == "Product") {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ProductDetails(
                                  locale: widget.locale,
                                  localizedValues: widget.localizedValues,
                                  productID: url['product'],
                                ),
                              ),
                            );
                          } else {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => SubCategories(
                                    locale: widget.locale,
                                    localizedValues: widget.localizedValues,
                                    catId: url['category'],
                                    catTitle:
                                        '${url['title'][0].toUpperCase()}${url['title'].substring(1)}',
                                    token: getTokenValue),
                              ),
                            );
                          }
                        },
                        child: Row(
                          children: <Widget>[
                            Text(MyLocalizations.of(context).ordernow),
                            Icon(Icons.arrow_right)
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              url['filePath'] == null && url['imageURL'] == null
                  ? Container()
                  : Positioned(
                      right: locale == 'ar' ? null : 0,
                      left: locale == 'ar' ? 0 : null,
                      child: Container(
                        height: 122,
                        width: 124,
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black.withOpacity(0.33),
                                blurRadius: 6)
                          ],
                          shape: BoxShape.circle,
                          image: DecorationImage(
                            image: NetworkImage((url['filePath'] == null
                                ? url['imageURL']
                                : Constants.IMAGE_URL_PATH +
                                    "tr:dpr-auto,tr:w-500" +
                                    url['filePath'])),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
            ],
          ),
        );
      }).toList(),
    );
  }

  productRow(titleTranslate, list) {
    return Column(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              titleTranslate,
              style: textBarlowMediumBlack(),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) => AllProducts(
                      locale: widget.locale,
                      localizedValues: widget.localizedValues,
                      productsList: list,
                      currency: currency,
                      token: getTokenValue,
                    ),
                  ),
                );
              },
              child: Text(
                MyLocalizations.of(context).viewAll,
                style: textBarlowMediumPrimary(),
              ),
            )
          ],
        ),
        SizedBox(
          height: 20,
        ),
        GridView.builder(
          physics: ScrollPhysics(),
          shrinkWrap: true,
          itemCount: list.length != null ? list.length : 0,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 14,
            mainAxisSpacing: 14,
            childAspectRatio: MediaQuery.of(context).size.width / 435,
          ),
          itemBuilder: (BuildContext context, int i) {
            if (list[i]['averageRating'] == null) {
              list[i]['averageRating'] = 0;
            }
            return list[i]['outOfStock'] != null ||
                    list[i]['outOfStock'] != false
                ? Padding(
                    padding: const EdgeInsets.all(1.0),
                    child: InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ProductDetails(
                              locale: widget.locale,
                              localizedValues: widget.localizedValues,
                              productID: list[i]['_id'],
                            ),
                          ),
                        );
                      },
                      child: Stack(
                        children: <Widget>[
                          ProductCard(
                            image: list[i]['filePath'] == null
                                ? list[i]['imageUrl']
                                : list[i]['filePath'],
                            isPath: list[i]['filePath'] == null ? false : true,
                            title: list[i]['title'],
                            currency: currency,
                            category: list[i]['category'],
                            price: double.parse(list[i]['variant'][0]['price']
                                .toStringAsFixed(2)),
                            mrp: list[i]['variant'][0]['MRP'],
                            unit: list[i]['variant'][0]['unit'].toString(),
                            dealPercentage: list[i]['isDealAvailable'] == true
                                ? double.parse(
                                    list[i]['delaPercent'].toStringAsFixed(1))
                                : null,
                            rating: list[i]['averageRating'] == null ||
                                    list[i]['averageRating'] == '0.0' ||
                                    list[i]['averageRating'] == 0.0
                                ? null
                                : list[i]['averageRating'].toStringAsFixed(1),
                            buttonName: null,
                            productList: list[i],
                            variantList: list[i]['variant'],
                          ),
                          list[i]['isDealAvailable'] == true
                              ? Positioned(
                                  child: Stack(
                                    children: <Widget>[
                                      Image.asset(
                                          'lib/assets/images/badge.png'),
                                      Padding(
                                        padding: const EdgeInsets.all(2.0),
                                        child: Text(
                                          " " +
                                              list[i]['delaPercent']
                                                  .toString() +
                                              "% " +
                                              MyLocalizations.of(context).off,
                                          style: hintSfboldwhitemed(),
                                          textAlign: TextAlign.center,
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              : Positioned(
                                  child: Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(2.0),
                                        child: Text(
                                          " ",
                                          style: hintSfboldwhitemed(),
                                          textAlign: TextAlign.center,
                                        ),
                                      )
                                    ],
                                  ),
                                )
                        ],
                      ),
                    ),
                  )
                : Stack(
                    children: <Widget>[
                      ProductCard(
                        image: list[i]['filePath'] ?? list[i]['imageUrl'],
                        title: list[i]['title'],
                        currency: currency,
                        category: list[i]['category'],
                        price: double.parse(
                            list[i]['variant'][0]['price'].toStringAsFixed(2)),
                        mrp: list[i]['variant'][0]['MRP'],
                        rating: list[i]['averageRating'].toStringAsFixed(1),
                        dealPercentage: list[i]['isDealAvailable'] == true
                            ? double.parse(
                                list[i]['delaPercent'].toStringAsFixed(1))
                            : null,
                        buttonName: null,
                        productList: list[i],
                        variantList: list[i]['variant'],
                      ),
                      CardOverlay()
                    ],
                  );
          },
        ),
      ],
    );
  }

  topDealsRow(titleTranslate, list, dealsType) {
    return Column(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              titleTranslate,
              style: textBarlowMediumBlack(),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) => AllDealsList(
                        locale: widget.locale,
                        localizedValues: widget.localizedValues,
                        productsList: list,
                        currency: currency,
                        token: getTokenValue,
                        dealType: dealsType,
                        title: titleTranslate),
                  ),
                );
              },
              child: Text(
                MyLocalizations.of(context).viewAll,
                style: textBarlowMediumPrimary(),
              ),
            )
          ],
        ),
        SizedBox(
          height: 20,
        ),
        Container(
          height: 200,
          child: ListView.builder(
            shrinkWrap: true,
            physics: ScrollPhysics(),
            scrollDirection: Axis.horizontal,
            itemCount: list.length != null ? list.length : 0,
            itemBuilder: (BuildContext context, int i) {
              return InkWell(
                onTap: () {
                  if (list[i]['delalType'] == 'Category') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SubCategories(
                            locale: widget.locale,
                            localizedValues: widget.localizedValues,
                            catId: list[i]['category'],
                            catTitle:
                                '${list[i]['name'][0].toUpperCase()}${list[i]['name'].substring(1)}',
                            token: getTokenValue),
                      ),
                    );
                  } else {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProductDetails(
                          locale: widget.locale,
                          localizedValues: widget.localizedValues,
                          productID: list[i]['product'],
                        ),
                      ),
                    );
                  }
                },
                child: Container(
                  width: 150,
                  margin: EdgeInsets.only(right: 15),
                  child: GFImageOverlay(
                    image: NetworkImage(list[i]['filePath'] == null
                        ? list[i]['imageUrl']
                        : Constants.IMAGE_URL_PATH +
                            "tr:dpr-auto,tr:w-500" +
                            list[i]['filePath']),
                    boxFit: BoxFit.cover,
                    color: Colors.black,
                    colorFilter: ColorFilter.mode(
                        Colors.black.withOpacity(0.40), BlendMode.darken),
                    borderRadius: const BorderRadius.all(Radius.circular(4)),
                    child: Padding(
                      padding: const EdgeInsets.only(
                          bottom: 10, left: 10, right: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Text(list[i]['name'],
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: textBarlowSemiBoldwbig()),
                          Text(
                            list[i]['delaPercent'].toString() +
                                "% " +
                                MyLocalizations.of(context).off,
                            style: textBarlowRegularrwhsm(),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  todayDealsRow(titleTranslate, list, dealsType) {
    return Column(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              titleTranslate,
              style: textBarlowMediumBlack(),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) => AllDealsList(
                        locale: widget.locale,
                        localizedValues: widget.localizedValues,
                        productsList: list,
                        currency: currency,
                        token: getTokenValue,
                        dealType: dealsType,
                        title: titleTranslate),
                  ),
                );
              },
              child: Text(
                MyLocalizations.of(context).viewAll,
                style: textBarlowMediumPrimary(),
              ),
            )
          ],
        ),
        SizedBox(
          height: 20,
        ),
        Container(
          height: 200,
          child: ListView.builder(
            physics: ScrollPhysics(),
            shrinkWrap: true,
            itemCount: list.length != null ? list.length : 0,
            scrollDirection: Axis.horizontal,
            itemBuilder: (BuildContext context, int i) {
              return InkWell(
                onTap: () {
                  if (list[i]['delalType'] == 'Category') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SubCategories(
                            locale: widget.locale,
                            localizedValues: widget.localizedValues,
                            catId: list[i]['category'],
                            catTitle:
                                '${list[i]['name'][0].toUpperCase()}${list[i]['name'].substring(1)}',
                            token: getTokenValue),
                      ),
                    );
                  } else {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProductDetails(
                          locale: widget.locale,
                          localizedValues: widget.localizedValues,
                          productID: list[i]['product'],
                        ),
                      ),
                    );
                  }
                },
                child: Container(
                  width: 150,
                  margin: EdgeInsets.only(right: 15),
                  child: GFImageOverlay(
                    image: NetworkImage(
                      list[i]['filePath'] == null
                          ? list[i]['imageUrl']
                          : Constants.IMAGE_URL_PATH +
                              "tr:dpr-auto,tr:w-500" +
                              list[i]['filePath'],
                    ),
                    boxFit: BoxFit.cover,
                    color: Colors.black,
                    colorFilter: ColorFilter.mode(
                        Colors.black.withOpacity(0.40), BlendMode.darken),
                    borderRadius: const BorderRadius.all(Radius.circular(4)),
                    child: Padding(
                      padding: const EdgeInsets.only(
                          bottom: 10, left: 10, right: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Text(
                              list[i]['delaPercent'].toString() +
                                  "% " +
                                  MyLocalizations.of(context).off,
                              style: textoswaldboldwhite()),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            list[i]['name'],
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: textBarlowmediumsmallWhite(),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      key: _scaffoldKeydrawer,
      body: SmartRefresher(
        enablePullDown: true,
        enablePullUp: false,
        controller: _refreshController,
        onRefresh: () {
          setState(() {
            isLoadingAllData = true;
            isBannerLoading = true;
            getBannerData();
            getAllDataMethod();
          });
        },
        child: isLoadingAllData
            ? SquareLoader()
            : categoryList.length == 0 &&
                    productsList.length == 0 &&
                    dealList.length == 0 &&
                    topDealList.length == 0 &&
                    bannerList.length == 0
                ? Center(
                    child: Image.asset('lib/assets/images/no-orders.png'),
                  )
                : SingleChildScrollView(
                    physics: ScrollPhysics(),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        children: <Widget>[
                          bannerList.length == 0
                              ? Container()
                              : SizedBox(height: 20),
                          bannerList.length == 0 ? Container() : banner(),
                          bannerList.length == 0
                              ? Container()
                              : SizedBox(height: 15),
                          categoryList.length == 0
                              ? Container()
                              : categoryRow(),
                          categoryList.length == 0 ? Container() : Divider(),
                          categoryList.length == 0
                              ? Container()
                              : SizedBox(height: 10),
                          topDealList.length == 0
                              ? Container()
                              : topDealsRow(
                                  MyLocalizations.of(context).topDeals,
                                  topDealList,
                                  "TopDeals"),
                          topDealList.length == 0
                              ? Container()
                              : SizedBox(height: 10),
                          topDealList.length == 0 ? Container() : Divider(),
                          topDealList.length == 0
                              ? Container()
                              : SizedBox(height: 10),
                          productRow(MyLocalizations.of(context).products,
                              productsList),
                          productsList.length == 0
                              ? Container()
                              : SizedBox(height: 10),
                          productsList.length == 0 ? Container() : Divider(),
                          productsList.length == 0
                              ? Container()
                              : SizedBox(height: 10),
                          dealList.length == 0
                              ? Container()
                              : todayDealsRow(
                                  MyLocalizations.of(context).dealsoftheday,
                                  dealList,
                                  "TodayDeals"),
                          dealList.length == 0
                              ? Container()
                              : SizedBox(height: 10),
                          dealList.length == 0 ? Container() : Divider(),
                          dealList.length == 0
                              ? Container()
                              : SizedBox(height: 10),
                        ],
                      ),
                    ),
                  ),
      ),
    );
  }
}
