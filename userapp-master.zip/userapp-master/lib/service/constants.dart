class Constants {
  // app name
  static const APP_NAME = "Daily Guru";

  // local url
//   static const BASE_URL = "http://1a9435f3c858.ngrok.io/";

  // deploy url
  static const BASE_URL = 'https://api.localz.co.in/';


//  static const BASE_URL = 'https://calypte.herokuapp.com/';

  // local url
  static final String socketUrl = BASE_URL.substring(0, BASE_URL.length - 1);

  // ONE_SIGNAL_KEY
  static const ONE_SIGNAL_KEY = "89e6763b-1d5a-457d-8a69-1adbcddc4a38";

  // googleapikey
  static const GOOGLE_API_KEY = "AIzaSyCRoywZJswLlzUOPJHr-lW2HaJikwxokEM";

  // stripe key
  static const STRIPE_KEY = "pk_test_RBdAu6jIbEByY3KaBQFbH4N100nMkViv6g";

  // image url
  static const IMAGE_URL_PATH = "https://ik.imagekit.io/1bjqvodqtd4/";
//  static const IMAGE_URL_PATH = "https://ik.imagekit.io/kplhvthqbi/";

}
